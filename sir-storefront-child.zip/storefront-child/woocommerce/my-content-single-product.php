<?php
/**
 * Variable product add to cart
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/add-to-cart/variable.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://woo.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 6.1.0
 */

defined( 'ABSPATH' ) || exit;

global $product;
?>
<div id="product-<?php the_ID(); ?>" <?php wc_product_class( '', $product ); ?>>

	<div class="sf_product_container">
        <div class="sf_product_title">
            <h1> <?php echo $product->get_name(); ?> </h1>            
        </div>
		<div class="sf_product_image">
			<?php echo do_action( 'woocommerce_before_single_product_summary' ); //$product->get_image(); ?>
		</div>
        <div class="sf_product_description">
            <p><?php echo $product->get_description(); ?></p>
        </div>
		
		<div class="sf_product_variations">
			<?php echo woocommerce_template_single_add_to_cart(); ?>
		</div>
		
	</div>
	
	
</div>

<?php do_action( 'woocommerce_after_single_product' ); ?>
