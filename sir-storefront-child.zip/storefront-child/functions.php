<?php

//remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_title', 5);
//remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_rating', 10);
//remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_price', 10);


/*
add_action('woocommerce_before_single_variation','my_test_hook');
function my_test_hook(){
	

	$get_logo_text = get_fields(get_the_ID(), 'logo_text', true);
	echo $get_logo_text['logo_text'];
	
}
add_filter( 'woocommerce_add_cart_item_data', 'custom_add_data_into_cart', 10, 2 );
function sf_custom_add_data_into_cart($cart_item_data, $product_id){
	$cart_item_data['logo_text'] = $_POST['logo_text'];
	return $cart_item_data;
}


function sf_display_data_in_cart_item_list( $item_data, $cart_item_data ) {
    if ( isset( $cart_item_data['logo_text'] ) ) {
        $item_data[] = array(
            'key'   => 'Logo Text',
            'value' => $cart_item_data['logo_text'],
        );
    }
    return $item_data;
}
add_filter( 'woocommerce_get_item_data', 'display_data_in_cart_item_list', 10, 2 );


function sf_set_order_line_item_meta( $item, $cart_item_key, $values, $order ) {
    if ( isset( $values['logo_text'] ) ) {
        $item->add_meta_data(
            'Logo Text',
            $values['logo_text'],
            true
        );
    }
}
add_action( 'woocommerce_checkout_create_order_line_item', 'set_order_line_item_meta', 10, 4 );
*/

